// middleware/authMiddleware.js
import jwt from "jsonwebtoken";

const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;

  // 1. Check if token exists and starts with "Bearer"
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ message: "No token provided. Please log in." });
  }

  // 2. Extract the token
  const token = authHeader.split(" ")[1];

  try {
    [cite_start]// 3. Verify the token using the secret from your .env [cite: 1]
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // 4. Attach the user ID from the decoded payload to the request for the controller to use
    // Assuming your JWT payload uses 'id' (as inferred from your existing auth.js/authMiddleware)
    req.userId = decoded.id; 
    next();
  } catch (err) {
    // Token is invalid, expired, or tampered with
    return res.status(401).json({ message: "Invalid token. Please re-authenticate." });
  }
};

export { authMiddleware };