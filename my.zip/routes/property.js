// routes/property.js

import express from "express";
import mongoose from "mongoose";
import Property from "../models/Property.js";
// ✅ IMPORT THE NEW AUTHENTICATION MIDDLEWARE
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// --------------------- POST NEW PROPERTY LISTING (PROTECTED ROUTE) ---------------------
// URL: /api/properties/list
router.post("/list", protect, async (req, res) => {
  // Data from frontend (SellProperty.jsx)
  const { 
    sellerName, 
    phoneNumber, 
    propertyType, 
    bhk, 
    city, 
    areaSqFt, 
    expectedPrice, 
    description, 
    imagePaths 
  } = req.body;
  
  // ✅ The user ID is guaranteed to be here because of the 'protect' middleware
  const userId = req.user.id; 

  // Basic Server-side validation
  if (!userId || !propertyType || !city || !areaSqFt || !expectedPrice || !description) {
    return res.status(400).json({ success: false, message: "Missing one or more required property fields." });
  }
  
  try {
    const newProperty = new Property({
      user: userId, // Link to the seller
      propertyType,
      bhk,
      city,
      areaSqFt,
      expectedPrice,
      description,
      sellerName,
      phoneNumber,
      imagePaths,
      status: 'pending' // Default status
    });

    const savedProperty = await newProperty.save(); // Save to MongoDB

    // Success response
    res.status(201).json({ 
      success: true, 
      message: "Property listing created successfully and awaiting approval.",
      _id: savedProperty._id 
    });
  } catch (err) {
    console.error("Error creating property listing:", err);
    res.status(500).json({ success: false, message: "Server error saving property listing." });
  }
});

// --------------------- GET ALL PROPERTIES (UNCHANGED) ---------------------
router.get("/", async (req, res) => {
  try {
    // Optionally, use .populate('user', 'email') to get seller details
    const properties = await Property.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, properties });
  } catch (err) {
    console.error("Error fetching properties:", err);
    res.status(500).json({ success: false, message: "Server error fetching properties" });
  }
});

// --------------------- GET PROPERTY BY ID (UNCHANGED) ---------------------
router.get("/:id", async (req, res) => {
  const { id } = req.params;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ success: false, message: "Invalid property ID" });
  }

  try {
    const property = await Property.findById(id).populate('user', 'email'); // Populate user data
    if (!property) return res.status(404).json({ success: false, message: "Property not found" });

    res.status(200).json({ success: true, property });
  } catch (err) {
    console.error("Error fetching property:", err);
    res.status(500).json({ success: false, message: "Server error fetching property" });
  }
});

export default router;