// models/Property.js

import mongoose from "mongoose";

const propertySchema = new mongoose.Schema({
  // ✅ NEW: Link property to the authenticated User (Seller)
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User', // Assuming you have a User model defined
    required: true,
  },
  
  // Details sent from SellProperty.jsx
  propertyType: { type: String, required: true }, // e.g., Apartment, Villa
  bhk: { type: String, required: true }, // e.g., 2 BHK
  city: { type: String, required: true }, // Location (city name)
  areaSqFt: { type: Number, required: true },
  expectedPrice: { type: Number, required: true },
  description: { type: String, required: true },

  // Seller Contact Details
  sellerName: { type: String, required: true },
  phoneNumber: { type: String, required: true },
  
  // Images (Stores the file names/paths)
  imagePaths: { type: [String], default: [] }, 
  
  // Status for approval/visibility on dashboard
  status: { 
    type: String, 
    enum: ['pending', 'approved', 'rejected', 'sold'],
    default: 'pending' 
  },
  
}, { 
  timestamps: true // Adds createdAt and updatedAt fields
});

const Property = mongoose.model("Property", propertySchema);
export default Property;